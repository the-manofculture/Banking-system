package com.bankapp;

public class Account {
    private String accountNumber;
    private String password;
    private String accountHolderName;
    private double balance;

    public Account(String accountNumber, String password, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.password = password;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
    }

    public String getAccountNumber() { return accountNumber; }
    public String getPassword() { return password; }
    public String getAccountHolderName() { return accountHolderName; }
    public double getBalance() { return balance; }
}
