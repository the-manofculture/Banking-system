package com.bankapp;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Account Number: ");
        String accNum = scanner.nextLine();

        System.out.print("Enter Password: ");
        String pwd = scanner.nextLine();

        Account account = AccountDatabase.getAccount(accNum, pwd);
        if (account != null) {
            System.out.println("---- Account Details ----");
            System.out.println("Account Holder Name: " + account.getAccountHolderName());
            System.out.println("Balance: " + account.getBalance());
        } else {
            System.out.println("Invalid account number or password.");
        }
        scanner.close();
    }
}
